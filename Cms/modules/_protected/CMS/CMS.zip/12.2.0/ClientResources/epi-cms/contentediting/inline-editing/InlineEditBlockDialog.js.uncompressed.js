define("epi-cms/contentediting/inline-editing/InlineEditBlockDialog", [
    "dojo/_base/declare",
    "dojo/topic",
    "epi/shell/widget/dialog/Dialog",
    "epi-cms/contentediting/move-behind-overlay",
    "epi/i18n!epi/cms/nls/episerver.shared.action"
], function (
    declare,
    topic,
    Dialog,
    moveBehindOverlay,
    actionRes
) {
    return declare([Dialog], {
        // summary:
        //      Dialog used to display inline edit form

        // saveLabel: [public] String
        //      Label for saving form
        saveLabel: actionRes.save,

        // mainCommand: [public] Object
        //      The command for changing the content's status (Publish, Ready to Publish, Ready for Review)
        mainCommand: null,

        // elementToOverlaySelector: [public] String
        //      Display the dialog overlay on top of a specific DOM node
        elementToOverlaySelector: ".epi-main-content",

        postMixInProperties: function () {
            this.inherited(arguments);

            this.dialogClass = "epi-dialog-portrait inline-edit-dialog";

            var containerNode = document.createElement("div");
            this.content = containerNode;
            this.contentClass = "epi-wrapped epi-mediaSelector";

            this.own(topic.subscribe("/epi/shell/inline-edit-resize", function (overlayPosition, sender) {
                if (this === sender || this._destroyed) {
                    return;
                }

                var dialogEl = this.domNode;
                moveBehindOverlay(dialogEl, overlayPosition);
            }.bind(this)));
        },

        getActions: function () {
            var actions = this.inherited(arguments);

            var saveButton = actions[0];
            saveButton.label = this.saveLabel;

            this._mainButtonName = "mainButton";
            var mainButton = {
                name: this._mainButtonName,
                label: this.mainCommand && this.mainCommand.label,
                title: null,
                settings: {
                    "class": "epi-success main-button"
                },
                action: function () {
                    this.onMainCommand();
                }.bind(this)
            };
            if (this.mainCommand) {
                actions.push(mainButton);
            }

            return actions;
        },

        _resizeOverlay: function () {
            var result = this.inherited(arguments);
            if (!result) {
                return result;
            }

            topic.publish("/epi/shell/inline-edit-resize", result, this);
        },

        hideSaveButton: function () {
            this.definitionConsumer.setItemProperty(this._okButtonName, "class", "dijitHidden");
        },

        toggleDisabledSaveButton: function (shouldDisable) {
            this.definitionConsumer.setItemProperty(this._okButtonName, "disabled", shouldDisable ? "disabled" : "");
        },

        toggleMainButton: function (visible) {
            if (visible) {
                this.definitionConsumer.setItemProperty(this._mainButtonName, "class", "epi-success main-button");
            } else {
                this.definitionConsumer.setItemProperty(this._mainButtonName, "class", "dijitHidden");
            }
        },

        toggleDisabledMainButton: function (shouldDisable) {
            this.definitionConsumer.setItemProperty(this._mainButtonName, "disabled", shouldDisable ? "disabled" : "");
        },

        _setCloseTextAttr: function (label) {
            this.definitionConsumer.setItemProperty(this._cancelButtonName, "label", label);
        },

        onMainCommand: function () {
        }
    });
});
