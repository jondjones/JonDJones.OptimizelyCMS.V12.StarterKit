//>>built
define("epi-cms/ApplicationSettings",[],function(){return {};});