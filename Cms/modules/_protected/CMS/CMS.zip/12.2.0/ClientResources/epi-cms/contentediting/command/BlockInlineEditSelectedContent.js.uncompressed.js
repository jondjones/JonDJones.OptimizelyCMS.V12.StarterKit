define("epi-cms/contentediting/command/BlockInlineEditSelectedContent", [
    "dojo/_base/declare",
    "./BlockInlineEdit",
    "epi/shell/command/_SelectionCommandMixin"
],

function (
    declare,
    BlockInlineEdit,
    _SelectionCommandMixin
) {
    return declare([BlockInlineEdit, _SelectionCommandMixin], {
        _execute: function () {
            this.model = this._getSingleSelectionData();
            this.inherited(arguments);
        },
        _onModelChange: function () {
            this.model = this._getSingleSelectionData();
            this.inherited(arguments);
        }
    });
});
